import axios from 'axios';

// Sua chave da API
const API_KEY: string = "AIzaSyAEAbvnvSD_eKroEztl_1wXtwqOcv-S8lQ";

// O CEP que você quer buscar
const cep: string = "04538-132";

// Define a estrutura dos componentes de endereço para facilitar a tipagem
interface AddressComponent {
    long_name: string;
    short_name: string;
    types: string[];
}

// Função assíncrona para buscar os dados do CEP
async function getAddressFromCEP(cep: string): Promise<void> {
    const url: string = `https://maps.googleapis.com/maps/api/geocode/json?address=${cep}&key=${API_KEY}`;

    try {
        const response = await axios.get(url);
        const data = response.data;

        if (data.status === 'OK') {
            const result = data.results[0];
            const addressComponents: AddressComponent[] = result.address_components;

            // Variáveis para armazenar as informações
            let cidade: string | undefined;
            let estado: string | undefined;
            let bairro: string | undefined;

            // Percorre os componentes de endereço para encontrar o que precisamos
            addressComponents.forEach(component => {
                if (component.types.includes("administrative_area_level_2")) {
                    cidade = component.long_name;
                }
                if (component.types.includes("administrative_area_level_1")) {
                    estado = component.short_name;
                }
                if (component.types.includes("sublocality_level_1")) {
                    bairro = component.long_name;
                }
            });

            console.log(`CEP: ${cep}`);
            console.log(`Bairro: ${bairro}`);
            console.log(`Cidade: ${cidade}`);
            console.log(`Estado: ${estado}`);

        } else {
            console.error(`Erro na API: ${data.status}`);
        }
    } catch (error) {
        if (axios.isAxiosError(error)) {
            console.error(`Erro na requisição: ${error.message}`);
        } else {
            console.error(`Erro inesperado: ${error}`);
        }
    }
}

// Chama a função para iniciar a busca
getAddressFromCEP(cep);